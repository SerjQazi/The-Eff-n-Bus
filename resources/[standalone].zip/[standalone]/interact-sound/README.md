# Interact Sound

Play sounds using the NUI environment in FiveM's FXServer.
