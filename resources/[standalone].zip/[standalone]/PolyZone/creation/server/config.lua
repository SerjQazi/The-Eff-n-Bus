Config = Config or {}
Config.ConfigFormatEnabled = false
-- Default Format

-- Name: TestBox | 2022-04-13T22:46:17Z
-- BoxZone:Create(vector3(-344.16, -103.25, 39.02), 1, 1, {
--     name = "TestBox",
--     heading = 0,
--     --debugPoly = true
--   })

-- Name: TestCircle | 2022-04-13T22:46:39Z
--   CircleZone:Create(vector3(-344.16, -103.25, 39.02), 1.0, {
--     name = "TestCircle",
--     useZ = false,
--     --debugPoly = true
--   })

--  Name: TestPoly | 2022-04-13T22:46:55Z
--   PolyZone:Create({
--     vector2(-344.15713500977, -103.24993896484),
--     vector2(-343.69491577148, -100.99839019775),
--     vector2(-345.53350830078, -102.00588226318)
--   }, {
--     name = "TestPoly",
--     minZ = 39.015644073486,
--     maxZ = 39.015865325928
--   })

-- Config Format

-- Name: TestBox | 2022-04-13T22:34:48Z
-- coords = vector3(-342.92, -102.09, 39.02),
-- length = 1,
-- width = 1,
-- name = "TestBox",
-- heading = 0,
-- debugPoly = true

-- Name: TestCircle | 2022-04-13T22:35:09Z
-- coords = vector3(-342.92, -102.09, 39.02),
-- radius = 1.0,
-- name = "TestCircle",
-- useZ = false,
-- debugPoly = true

-- Name: TestPoly | 2022-04-13T22:35:43Z
-- points = {
--   vector2(-342.91537475586, -102.09281158447),
--   vector2(-344.09732055664, -104.0821762085),
--   vector2(-342.01580810547, -105.60903167725)
-- },
-- name = "TestPoly",
-- minZ = 39.015701293945,
-- maxZ = 39.015705108643,
-- debugPoly = true
