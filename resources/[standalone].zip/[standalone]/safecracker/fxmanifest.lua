fx_version 'bodacious'
game 'gta5'

description 'Safecracker Minigame'
version '1.0.0'

client_scripts {
  'config.lua',
  'client.lua'
}

files { 
  'LockPart1.png',
  'LockPart2.png',
}
