CreateThread(function()
    RequestIpl("h4_ch2_mansion_final")
end)