# Running the source files

- `npm i`
- `grunt` to build
- `grunt watch` to watch for changes